# TalentFlow AI — HR Impress Edition

A polished, responsive recruitment-workspace **prototype** for a portfolio / HR demo.

## Included in this build
- Responsive dashboard and recruitment metrics
- Job search, filters, skill keyword match score, save jobs and apply actions
- Candidate profile editor
- Recruiter studio: create/remove demo job listings and update application stages
- Application tracker
- Resume Lab: local `.txt` keyword scan; PDF/DOCX can be selected but are not parsed by this frontend-only version
- Browser-local persistence using `localStorage`

## Important truth about this prototype
This is a frontend demo. The match score is keyword-based, not a trained AI model. It does not have real authentication, a shared database, real multi-user accounts, secure resume storage, or server-side AI. Do not use it for real candidate data yet.

## Deploy to GitHub Pages
1. Download and extract the ZIP.
2. In your repository `xoxoprans/TALENTFLOW-AI-RECRUITMENT`, back up the current `index.html`.
3. Upload the new `index.html` to the repository root (same level as the current homepage), replacing the old file.
4. Commit with message: `Upgrade TalentFlow AI HR demo experience`
5. Wait for GitHub Pages deployment to finish, then refresh the website. On Android Chrome, try opening in a private tab if old content is cached.

## To make it production-ready
Add a backend (for example Supabase + server-side functions), row-level access policies, validated authentication, secure resume parsing/storage, and an AI provider called only from a server-side function. Never place private API keys in `index.html` or public GitHub files.
