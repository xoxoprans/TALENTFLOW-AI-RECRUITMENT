# TalentFlow AI — Recruitment Workspace

Responsive, single-page recruitment demo with:
- Overview dashboard and local skill-overlap matching
- Job browsing, text search, work-type/level filters
- Candidate profile editor
- Save jobs and apply/withdraw flow
- Recruiter job listing creation and deletion
- Application tracking
- Local browser persistence via localStorage
- Mobile-responsive layout

## Run locally
Open `index.html` in a browser.

## Deploy to GitHub Pages
1. Back up your existing repository first.
2. Copy `index.html` into the repository root (replace only if you intend to replace the current homepage).
3. Commit the change to your main branch.
4. Keep repository Settings → Pages → Build and deployment → Source set to GitHub Actions if using the existing workflow.
5. Check Actions for a successful deployment.

## Important limitations
This is a frontend demo. Data is stored in the current browser only. Matching is keyword overlap, not a real AI model. Real AI, shared recruiter/candidate data, authentication, file uploads, and production applications require a secure backend and API integration. Never put private API keys in frontend JavaScript.
